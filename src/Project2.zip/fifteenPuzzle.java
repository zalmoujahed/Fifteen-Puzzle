
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class fifteenPuzzle {
	

	public static void main(String[] args) {
		GUI app  = new GUI();
		app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

}
